<div class="col-md-12 table-responsive">
    <table class="table table-hover">
        <tr>
            <th>Personel Number</th>
            <th>First Name</th>
            <th>Middle Name</th>
            <th>LastName</th>
            <th>SSN</th>
            <th>Job Location</th>
            <th>Manager</th>
            <th>HR Rep</th>
            <th>Field Admin</th>
            <th>Drug Pool</th>
            <th>Modify</th>
        </tr>
        <?php if($members): ?>
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($member->personel_number); ?>

                    </td>
                    <td>
                        <?php echo e($member->first_name); ?>

                    </td>
                    <td>
                        <?php echo e($member->middle_name); ?>

                    </td>
                    <td>
                        <?php echo e($member->last_name); ?>

                    </td>
                    <td>
                        <?php echo e($member->ssn); ?>

                    </td>
                    <td>
                        <?php echo e($member->job_location); ?>

                    </td>
                    <td>
                        <?php echo e($member->manager); ?>

                    </td>
                    <td>
                        <?php echo e($member->hr_rep); ?>

                    </td>
                    <td>
                        <?php echo e($member->field_admin); ?>

                    </td>
                    <td>
                        <?php echo e($member->drug_pool); ?>

                    </td>
                    <td>
                        <div><a href="members/edit/<?php echo e($member->id); ?>"><i class="fa fa-edit "></i></a> &nbsp|&nbsp <a href="members/edit/remove/<?php echo e($member->id); ?>"><i class="fa fa-remove"></i></a></div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr><td>there are no un selected members currently.</td></tr>
        <?php endif; ?>
    </table>
</div>