<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if($errors->any()): ?>
            <div>
                <span class="alert-danger">
                    <?php if($errors->has('import')): ?>
                    <?php echo e($errors->import->first()); ?>

                    <?php endif; ?>
                    <?php echo e($errors->all()); ?>

                </span>
            </div>
        <?php endif; ?>

    <div class="col-md-4 form-group">
            <?php echo e(Form::open(['method'=>'post', 'class'=>'form form-horizontal'])); ?>

                <select name="pool" class="form-control">
                    <option value="all" selected>All</option>
                    <?php $__currentLoopData = $pools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pool->drug_pool); ?>"><?php echo e($pool->drug_pool); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo e(Form::submit('Change Drug Pool',['class'=>'btn btn-primary'])); ?>

            <?php echo e(Form::close()); ?>

    </div>
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <ul class="pagination">
            <?php
            //$pagination = $mrs->Pagination();
            ?>
            <a href="viewselected.php"><button class="btn btn-primary">Export Selected Members</button></a>
        </ul>
    </div>
    <?php echo $__env->make('members.membersTable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>