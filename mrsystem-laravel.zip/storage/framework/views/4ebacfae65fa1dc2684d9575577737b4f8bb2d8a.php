

<?php $__env->startSection('content'); ?>
    <div class="container">
            <div class="col-md-4"></div>
            <div class="col-md-4 form-group" align="center">
                <p>Select Random Users</p>
                <form method="post">
                    <?php echo e(csrf_field()); ?>

                    <label for="rand-num" class="form-label" >Select # Users</label>
                    <input type="number" id="rand-num" name="rand_num" class="form-control" value="4">
                    <label for="pool" class="form-label">From This Pool</label>
                    <select name="pool" class="form-control">
                        <option value="all" selected>All</option>
                        <?php $__currentLoopData = $pools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pool->drug_pool); ?>"><?php echo e($pool->drug_pool); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="submit" name="selectRandom" class="btn btn-primary" value="Select Random Users">
                </form>
            </div>
        </div>
        <?php if(isset($members)): ?>
            <div class="col-md-12" align="center">
                <a href="<?php echo e(route('export')); ?>"><button class="btn btn-primary">Select & Export</button></a>
            </div>
            <?php echo $__env->make('members.membersTable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <?php endif; ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>