<!--
/**
 * Created by PhpStorm.
 * User: Micheal Mueller - MuellerTek
 * Web: http://www.MuellerTek.com
 * Date: 4/15/2017, 8:50 PM
 *__/\\\\____________/\\\\_______________________________/\\\\\\_____/\\\\\\__________________________________/\\\\\\\\\\\\\\\______________________________
 * _\/\\\\\\________/\\\\\\______________________________\////\\\____\////\\\_________________________________\///////\\\/////__________________/\\\_________
 *  _\/\\\//\\\____/\\\//\\\_________________________________\/\\\_______\/\\\_______________________________________\/\\\______________________\/\\\_________
 *   _\/\\\\///\\\/\\\/_\/\\\__/\\\____/\\\_____/\\\\\\\\_____\/\\\_______\/\\\________/\\\\\\\\___/\\/\\\\\\\________\/\\\___________/\\\\\\\\__\/\\\\\\\\____
 *    _\/\\\__\///\\\/___\/\\\_\/\\\___\/\\\___/\\\/////\\\____\/\\\_______\/\\\______/\\\/////\\\_\/\\\/////\\\_______\/\\\_________/\\\/////\\\_\/\\\////\\\__
 *     _\/\\\____\///_____\/\\\_\/\\\___\/\\\__/\\\\\\\\\\\_____\/\\\_______\/\\\_____/\\\\\\\\\\\__\/\\\___\///________\/\\\________/\\\\\\\\\\\__\/\\\\\\\\/___
 *      _\/\\\_____________\/\\\_\/\\\___\/\\\_\//\\///////______\/\\\_______\/\\\____\//\\///////___\/\\\_______________\/\\\_______\//\\///////___\/\\\///\\\___
 *       _\/\\\_____________\/\\\_\//\\\\\\\\\___\//\\\\\\\\\\__/\\\\\\\\\__/\\\\\\\\\__\//\\\\\\\\\\_\/\\\_______________\/\\\________\//\\\\\\\\\\_\/\\\_\///\\\_
 *        _\///______________\///___\/////////_____\//////////__\/////////__\/////////____\//////////__\///________________\///__________\//////////__\///____\///__
 */-->

<div class="col-md-12 table-responsive">
    <table class="table table-hover">
        <tr>
            <th>Personel Number</th>
            <th>First Name</th>
            <th>Middle Name</th>
            <th>LastName</th>
            <th>SSN</th>
            <th>Job Location</th>
            <th>Manager</th>
            <th>HR Rep</th>
            <th>Field Admin</th>
            <th>Drug Pool</th>
            <th>Modify</th>
        </tr>
        <?php if($members): ?>
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($member->personel_number); ?>

                    </td>
                    <td>
                        <?php echo e($member->first_name); ?>

                    </td>
                    <td>
                        <?php echo e($member->middle_name); ?>

                    </td>
                    <td>
                        <?php echo e($member->last_name); ?>

                    </td>
                    <td>
                        <?php echo e($member->ssn); ?>

                    </td>
                    <td>
                        <?php echo e($member->job_location); ?>

                    </td>
                    <td>
                        <?php echo e($member->manager); ?>

                    </td>
                    <td>
                        <?php echo e($member->hr_rep); ?>

                    </td>
                    <td>
                        <?php echo e($member->field_admin); ?>

                    </td>
                    <td>
                        <?php echo e($member->drug_pool); ?>

                    </td>
                    <td>
                        <div><a href="members/edit/' . <?php echo e($member->id); ?>. '"><i class="fa fa-edit "></i></a> &nbsp|&nbsp <a href="route.php?deluser=1&user_id=' . <?php echo e($member->id); ?> . '"><i class="fa fa-remove"></i></a></div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr><td>there are no un selected members currently.</td></tr>
        <?php endif; ?>
    </table>
</div>