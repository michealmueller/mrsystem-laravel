
<!-- Static navbar -->
<nav class="navbar navbar-toggleable-md navbar-light bg-faded">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Drug Pool</a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('selected')); ?>">View Selected</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('import')); ?>">Import Users</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('random')); ?>">Random Selection</a></li>
                <?php if(Auth::check()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
</nav>